#include<stdio.h>

typedef int keytype;
typedef float othertype;
typedef struct {
	keytype key;
	othertype otherfields;
}recordtype;

void swap(recordtype *x, recordtype *y){
	recordtype temp;
	temp = *x;
	*x = *y;
	*y = temp;
}

void pushDown(recordtype a[], int first, int last){
	int r = first;
	while( r <= (last-1)/2 ){
		if( last == 2*r+1 ){
			if( a[r].key > a[last].key ){
				swap(a[r], a[last]);
			}
			r = last;
		}else{
		}
	}
}

void read(recordtype a[], int *n){
	FILE *f;
	f = fopen("data.txt", "r");
	int i = 0;
	if(f!=NULL){
		while(!feof(f)){
			fscanf(f, "%d%f", &a[i].key, &a[i].otherfields);
			i++;
		}
	}else{
		printf("Loi! Khong the doc file.");
	}
	fclose(f);
	*n = i;
}

void print(recordtype a[], int  n){
	int i;
	for(i = 0; i < n; i++){
		printf("%3d %5d %8.2f\n", i+1, a[i].key, a[i].otherfields);
	}
	printf("\n");
}

int main(){
	
	return 0;
}
